from django.urls import path
from .views import *

app_name = 'orders'

urlpatterns = [
    path('order/', order, name='order'),
    path('order_complete', order_complete, name='order_complete'),
    path('dashboard/', dashboard, name='dashboard'),
]