from .models import order_model, order_items

def order_details(request):
    details = order_model.objects.order_by('-orderdate') # '-orderdate' used for desc order
    return dict(order_details=details)

def orderhistory(request):
    details = order_items.objects.all()
    return dict(orderhistory=details)